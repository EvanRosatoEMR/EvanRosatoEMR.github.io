﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventuerShit
{
    class Structure
    {
        public enum cate
        {
            WALL,
            CHEST
        }

        public enum direc
        {
            NORTH,
            SOUTH,
            EAST,
            WEST
        }

        private cate Category;
        private direc Direction;

        private int ID;
        private string Description;
        private string Name;
        public Structure(string name, int id, string desc, cate typ, direc dir)
        {
            Name = name;
            ID = id;
            Description = desc;
            Category = typ;
            Direction = dir;
        }

        public int IdNum
        {
            get { return ID; }
            set { ID = value; }
        }

        public string Namer
        {
            get { return Name; }
            set { Name = value; }
        }

        public string Descriptor
        {
            get { return Description; }
            set { Description = value; }
        }

        public direc Directioner
        {
            get { return Direction; }
            set { Direction = value; }
        }
        public cate Categorier
        {
            get { return Category; }
            set { Category = value; }
        }

        public void structEval()
        {
            if (ID == 1)
            {
                Room.Roomie.removeStruct();
            }

        }
    }
}
