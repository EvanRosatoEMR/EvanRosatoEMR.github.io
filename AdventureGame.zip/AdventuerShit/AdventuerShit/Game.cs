﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace AdventuerShit
{
    class Game
    {

        //public static Room currentRoom = null;
        public static Room[] roomList = new Room[100];
        public static Player you = new Player();
        public Game()
        {
            roomInit();
            Console.Title = "Quiet Hour";

            startUp();
            action();
        }

        public void action()
        {
            string action = "";

            while (true)
            {
                action = Prompt("");
                you.actionEval(action);
            }
        }

        public void startUp()
        {
            you.Name = Prompt("What's your name?");
            Sayso($"The room is quiet.", 2000);
            Sayso($"Your head is throbbing.", 2000);
            Sayso($"You can barely stand, but upon seeing your surroundings, you muster the strength.", 2500);
            Sayso($"", 2500);
            Room.Roomie.DisplayRoom();
            Sayso(Room.Roomie.Descriptor, 2000);
        }

        static void Sayso(string text)
        {
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
        }

        static void Sayso(string text, int delay)
        {
            Thread.Sleep(delay);
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
        }

        static string Prompt(string text)
        {
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
            return Console.ReadLine();
        }

        static string Prompt(string text, int delay)
        {
            Thread.Sleep(delay);
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (text.Length / 2)) + "}", text));
            return Console.ReadLine();
        }

        static void roomInit()
        {

            Item theKey = new Item("KEY", 01, true, false);
            Structure lastDoor = new Structure("DOOR", 01, "A locked door.", 0, 0);

            Room test = new Room("start", "The room is trashed, the walls and floor stained in blood. All the shelves have been ransacked, and the NORTH door beside the closet hangs open.", "QH_Room1.txt", null);
            Room test2 = new Room("hall", "The hallway is barely lit. Bloodstains scatter the area, leading WEST and NORTH. Your room is to the EAST.", "QH_Room2.txt", null);
            Room test3 = new Room("roomB", "A man sits against the wall, covered in blood, trailing behind him and up the wall to part of a code. There's a KEY on the ground.", "QH_Room3.txt", theKey);
            Room test4 = new Room("last", "The exit is directly NORTH.", "QH_Room4.txt", null, lastDoor);
            Room test5 = new Room("end", "You Win!", "banner.txt", null);

            test.North = test2;

            test2.East = test;
            test2.West = test3;
            test2.North = test4;

            test3.North = test2;

            test4.South = test2;
            test4.North = test5;

            Room.Roomie = test;
        }

    }
}
