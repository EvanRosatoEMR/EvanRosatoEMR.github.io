﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventuerShit
{
    class Inventory
    {
        private List<Item> items = new List<Item>();
        public Inventory()
        {

        }

        public List<Item> Items
        {
            get { return items; }
        }

        public void addItem(Item item)
        {
            items.Add(item);

        }

        public void addItemPlayer(Item item)
        {
            if (item.CanGet)
            {
                items.Add(item);
            }
            else
            {
                Console.WriteLine("Cannot.");
            }
        }

        public void removeItem(Item item)
        {
            if (item.Renew == false)
            {
                items.Remove(item);
            } else
            {
                Console.WriteLine("There's More.");
            }
        }

        public Item getItem()
        {
            return null;
        }

        public void printInven()
        {
            foreach (Item item in items)
            {
                string name = item.Namer;
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (name.Length / 2)) + "}", name));
            }
        }
    }
}
