﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventuerShit
{
    class Player
    {
        public bool is_Blind = false;
        public bool is_Hurt = false;
        public string Name = "You";

        private Inventory playInven = new Inventory();
        public Player()
        {

        }

        public Inventory yourInven
        {
            get { return playInven; }
        }

        public void actionEval(string action)
        {
            string[] command = action.Split(" ");

            switch (command[0].ToUpper())
            {
                case "GO":

                    if (command.Length < 2)
                    {
                        Console.WriteLine("Go where?");
                        break;
                    }

                    switch (command[1].ToUpper())
                    {
                        case "NORTH":

                            if (Room.Roomie.roomStruct != null)
                            {
                                if (Room.Roomie.roomStruct.Categorier == 0 && Room.Roomie.roomStruct.Directioner == 0)
                                {
                                    Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.roomStruct.Descriptor.Length / 2)) + "}", Room.Roomie.roomStruct.Descriptor));
                                }
                            }
                            else if (Room.Roomie.North != null)
                            {
                                Room.Roomie = Room.Roomie.North;
                                Room.Roomie.DisplayRoom();
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.Descriptor.Length / 2)) + "}", Room.Roomie.Descriptor));
                            } 
                            else
                            {
                                string assie = "There's nothing that way.";
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (assie.Length / 2)) + "}", assie));
                            }
                            break;

                        case "SOUTH":
                            if (Room.Roomie.South != null)
                            {
                                Room.Roomie = Room.Roomie.South;
                                Room.Roomie.DisplayRoom();
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.Descriptor.Length / 2)) + "}", Room.Roomie.Descriptor));
                            }
                            else
                            {
                                string assie = "There's nothing that way.";
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (assie.Length / 2)) + "}", assie));
                            }
                            break;

                        case "EAST":
                            if (Room.Roomie.East != null)
                            {
                                Room.Roomie = Room.Roomie.East;
                                Room.Roomie.DisplayRoom();
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.Descriptor.Length / 2)) + "}", Room.Roomie.Descriptor));
                            }
                            else
                            {
                                string assie = "There's nothing that way.";
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (assie.Length / 2)) + "}", assie));
                            }
                            break;

                        case "WEST":
                            if (Room.Roomie.West != null)
                            {
                                Room.Roomie = Room.Roomie.West;
                                Room.Roomie.DisplayRoom();
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.Descriptor.Length / 2)) + "}", Room.Roomie.Descriptor));
                            }
                            else
                            {
                                string assie = "There's nothing that way.";
                                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (assie.Length / 2)) + "}", assie));
                            }
                            break;

                        default:
                            string ass = "That's not a direction.";
                            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (ass.Length / 2)) + "}", ass));
                            break;
                    }
                    break;

                case "HELP":
                    string[] actList = {"GO (Direction): Move to the room in the specified direction. (North, South, East, West.)",
                                        "LOOK: Look around the room.", "USE (Item): Use the specified object.", "CHECK (Room/Structure): Check the room, or the specified structure.",
                                        "GRAB (Item): Grab the listed item.", "INVENTORY: Display your inventory."};
                    foreach (string act in actList)
                    {
                        Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (act.Length / 2)) + "}", act));
                    }
                    break;

                case "USE":

                    if (command.Length < 2)
                    {
                        Console.WriteLine("Use what?");
                        break;

                    } else if (command.Length < 5 && command[2].ToUpper() == "ON") {

                        string usage = command[1].ToUpper();
                        bool vr = false;

                        int itemNum = -1;
                        int structNum = -2;

                        Item theItem = null;
                        Structure theStruct;

                        foreach (Item item in playInven.Items)
                        {

                            if (item.Namer == usage)
                            {
                                itemNum = item.IDen;
                                theItem = item;
                                vr = true;
                                break;
                            }
                        }

                        if (command[3].ToUpper() == Room.Roomie.roomStruct.Namer)
                        {
                            structNum = Room.Roomie.roomStruct.IdNum;
                        } else
                        {
                            Console.WriteLine($"Whatever you're trying to use {usage} on isn't here.");
                            break;
                        }

                        if (itemNum == structNum)
                        {
                            Room.Roomie.roomStruct.structEval();

                            playInven.removeItem(theItem);
                        }

                        if (vr == false)
                        {
                            Console.WriteLine("You don't have that...");
                        }
                    }

                    break;

                case "CHECK":

                    if (command.Length < 2)
                    {
                        Console.WriteLine("Check what?");
                        break;
                    }
                    string what = command[1].ToUpper();

                    if (what == "ROOM")
                    {
                        Room.Roomie.itsInven.printInven();
                    }
                    break;

                case "GRAB":

                    if (command.Length < 2)
                    {
                        Console.WriteLine("Grab what?");
                        break;
                    }

                    string yours = command[1].ToUpper();
                    bool rv = false;

                    foreach (Item item in Room.Roomie.itsInven.Items)
                    {

                        if (item.Namer == yours)
                        {
                            playInven.addItemPlayer(item);
                            Room.Roomie.itsInven.removeItem(item);
                            rv = true;
                            break;
                        }
                    }

                    if (rv == false)
                    {
                        Console.WriteLine("There's nothing of the sort in this room...");
                    }

                    break;

                case "INVENTORY":
                    if (playInven.Items.Count == 0)
                    {
                        Console.WriteLine("You're empty-handed...");
                    } else
                    {
                        foreach (Item item in playInven.Items)
                        {
                            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (item.Namer.Length / 2)) + "}", item.Namer));
                        }
                    }
                    break;

                case "LOOK":
                    Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Room.Roomie.Descriptor.Length / 2)) + "}", Room.Roomie.Descriptor));
                    break;
                default:

                    string huh = "Huh?";
                    Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (huh.Length / 2)) + "}", huh));
                    break;
            }
        }
    }
}
