﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventuerShit
{
    class Item
    {
        private string Name;
        private int ID = 0;
        private bool canGet;
        private bool renewAble;
        public Item(string name, int id, bool get, bool renew)
        {
            Name = name;
            ID = id;
            canGet = get;
            renewAble = renew;
        }

        public string Namer
        {
            get { return Name; }
        }
        public int IDen
        {
            get { return ID; }
        }
        public bool CanGet
        {
            get { return canGet; }
        }
        public bool Renew
        {
            get { return renewAble; }
        }
    }
}
