﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace AdventuerShit
{
    class Room
    {
        private string Name;
        private string Description;
        private string Layout;

        public Room North;
        public Room South;
        public Room West;
        public Room East;

        private static Room currentRoom = null;

        private Inventory roomInven = new Inventory();

        public Structure roomStruct;

        public Room(string name, string desc, string lay, Item item)
        {
            Name = name;
            Description = desc;
            Layout = lay;

            if (item != null)
            {
                roomInven.addItem(item);
            }
        }

        public Room(string name, string desc, string lay, Item item, Structure struc)
        {
            Name = name;
            Description = desc;
            Layout = lay;

            roomStruct = struc;

            if (item != null)
            {
                roomInven.addItem(item);
            }
        }

        public string Namer
        {
            get { return Name; }
            set { Name = value; }
        }

        public string Descriptor
        {
            get { return Description; }
            set { Description = value; }
        }

        public string Layoutie
        {
            get { return Layout; }
            set { Layout = value; }
        }

        public static Room Roomie
        {
            get { return currentRoom; }
            set { currentRoom = value; }
        }

        public Inventory itsInven
        {
            get { return roomInven; }
        }

        public void DisplayRoom()
        {
            string[] Layer = File.ReadAllLines(Layout);

            for (int i = 0; i < Layer.Length; i++)
            {
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Layer[i].Length / 2)) + "}", Layer[i]));

                //Game.Sayso(Layer[i]);
            }
        }

        public void removeStruct()
        {
            roomStruct = null;
        }
    }
}
