﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace AdventuerShit
{
    class Program
    {
        static void Main()
        {
            string textToEnter;

            Console.SetWindowPosition(0, 0);

            textToEnter = "NOTE: This game is made for Fullscreen play.";
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (textToEnter.Length / 2)) + "}", textToEnter));

            textToEnter = "Press any key to Continue, or Esc to Exit.";
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (textToEnter.Length / 2)) + "}", textToEnter));

            var myKey = Console.ReadKey();

            if (myKey.Key == ConsoleKey.Escape)
            {
                Environment.Exit(0);
            }
            else
            {
                Game QHGame = new Game();
            }
        }
    }
}
