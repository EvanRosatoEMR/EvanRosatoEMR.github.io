import re

words = open("words_alpha.txt", 'r')
wordList = words.read().splitlines()
finaList = []

print("Suck at SCRABBLE? Me too!\nI was getting annoyed at games like SCRABBLE and Word Crossy and shit so made this instead of doing something better with my life\n")
yourLets = input("Enter your letters here. Make sure to include all duplicates!")
yourMin = input("What is the MINIMUM amount of letters you want the words to have? (Enter nothing to skip this.)")
yourMax = input("What is the MAXIMUM amount of letters you want the words to have? (Enter nothing to skip this.)")

if yourMin == "":
    yourMin = '0'

if yourMax == "":
    yourMax = '999'

if yourLets.isalpha() and yourMin.isnumeric() and yourMax.isnumeric():
    print("\nAlright, I'm workin' on it...")
    yourList = list(yourLets)
    longestWord = ""
    longestWords = ["a"]
    
    for word in wordList:
        regCheck = re.findall("[" + yourLets + "]", word)

        if regCheck and len(word) >= int(yourMin) and len(word) <= int(yourMax):

            splitWord = list(word)
        
            for let in yourList:
                if len(splitWord):
                    if let in splitWord:
                        here = splitWord.index(let)
                        splitWord.pop(here)
                else:
                    break

        else:
            continue

        if len(splitWord) == 0: 
            finaList.append(word)

            if len(word) >= len(longestWord):
                if len(word) > len(longestWord):
                    longestWord = word
                    longestWords.clear()
                longestWords.append(word)
                

    if len(finaList) > 0:
        print("\nOkay, your words are: ")
        print(finaList)
        print("\nThe longest word(s) you can make are: ")
        print(longestWords)
        print("\nKeep in mind that not every game uses the same dictionary, so if a word doesn't work in one game, it still might in another.")

    else:
        print("\nOh dear...it seems that you can't make any words with the letters you gave. Maybe you entered them wrong?")

else:
    print("\nSomething's wrong with your letters...Make sure to not include spaces or puncuation of any kind.\nClose the program and try again.")

