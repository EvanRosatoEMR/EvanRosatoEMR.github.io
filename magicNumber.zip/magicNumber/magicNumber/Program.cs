﻿using System;

namespace magicNumber
{
    class Program
    {
        public static string[] numList = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", 
                              "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Enter a number from 0-20. (Any other to EXIT)");
                int yourNum = Convert.ToInt32(Console.ReadLine());
                if (yourNum < 0 || yourNum > 20) { break; }
                int loopCount = numberPath(yourNum);

                Console.WriteLine("It takes " + loopCount + " loops to get to the Magic Number from " + yourNum);
            }
        }
        static int numberPath(int yourNum)
        {
            string numWord;
            int currentNum = yourNum;
            int loopNum = 0;

            while (true)
            {
                numWord = numList[currentNum];
                Console.WriteLine(numWord + " -> " + numWord.Length);

                if (numWord == "four")
                {
                    break;
                } else
                {
                    loopNum++;
                    currentNum = numWord.Length;
                }
                
            }

            return loopNum;
        }
    }
}
